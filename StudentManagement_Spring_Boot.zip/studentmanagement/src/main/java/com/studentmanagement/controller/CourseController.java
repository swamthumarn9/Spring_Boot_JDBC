package com.studentmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.studentmanagement.dao.CourseDAO;
import com.studentmanagement.dto.CourseRequestDTO;
import com.studentmanagement.model.CourseBean;



@Controller
public class CourseController {
	@Autowired
	private CourseDAO courseDao;
	
	@GetMapping (value="/setupaddcourse")
	public ModelAndView addcourse() {
		return new ModelAndView ("BUD003", "courseBean", new CourseBean()); 
	}
	
	
	@RequestMapping(value="/addcourse", method=RequestMethod.POST)
	public String addCourse(@ModelAttribute("courseBean") @Validated CourseBean courseBean, BindingResult bs,
			ModelMap model) {
		if(bs.hasErrors()) {
			return "BUD003";
		}
		if(courseBean.getCourseId().equals("") || courseBean.getCourseName().equals("")) {
			model.addAttribute("error", "Fill Blanks!");
			return "BUD003";
			}else {
				CourseRequestDTO  dto=new CourseRequestDTO();
				dto.setCourseId(courseBean.getCourseId());
				dto.setCourseName(courseBean.getCourseName());
				
				int rs=courseDao.insertCourse(dto);
				if(rs==0) {
					model.addAttribute("error","Insert Failed");
					return "BUD003";
				}
				model.addAttribute("success", "Successful Register");
				return "BUD003";	
			}	
	}
}
