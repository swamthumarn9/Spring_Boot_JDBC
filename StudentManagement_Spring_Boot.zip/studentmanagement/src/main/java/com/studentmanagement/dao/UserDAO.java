package com.studentmanagement.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.studentmanagement.dto.UserRequestDTO;
import com.studentmanagement.dto.UserResponseDTO;

@Repository
public class UserDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;
	public int insertUser(UserRequestDTO userdto) {
		int result=0;
		String sql="insert into users (user_id, user_name, user_password, "
				+ "user_confirmpassword, user_role) values (?,?,?,?,?)";
		
		result=jdbcTemplate.update(sql,
				userdto.getUserID(),userdto.getUserName(),userdto.getUserPassword(),
				userdto.getUserConfirmPassword(),userdto.getUserRole());
		return result;
	}
	
	public int updateUser(UserRequestDTO userdto) {
		int result=0;
		String sql="update users set user_name=?, user_password=?, user_confirmpassword=?, user_role=? where user_id=?";
		
		result=jdbcTemplate.update(sql,
				userdto.getUserName(),userdto.getUserPassword(),userdto.getUserConfirmPassword(),
				userdto.getUserRole(),userdto.getUserID());
		return result;
	}
	
	public int deleteUser(UserRequestDTO userdto) {
		int result=0;
		String sql="delete from users where user_id=?";
		
		result=jdbcTemplate.update(sql,
				userdto.getUserID());
		return result;
	}
	
	public UserResponseDTO selectOne(UserRequestDTO userdto) {
		
		String sql="select * from users where user_id=?";
		
		return jdbcTemplate.queryForObject(sql,
				(rs,rowNum)->
					new UserResponseDTO(rs.getString("user_id"),
							rs.getString("user_name"),
							rs.getString("user_password"),
							rs.getString("user_confirmpassword"),
							rs.getString("user_role")),
					userdto.getUserID());
	}
	
	public List<UserResponseDTO> selectUserById(String Id) {
		
		String sql="select * from users where user_id=?";
		return jdbcTemplate.query(sql,
				(rs,rowNum)->
					new UserResponseDTO(rs.getString("user_id"),
							rs.getString("user_name"),
							rs.getString("user_password"),
							rs.getString("user_confirmpassword"),
							rs.getString("user_role")),
					Id);
	}
	
	
	public List<UserResponseDTO> selectUserByName(String Name) {
		
		String sql="select * from users where user_name Like ?";
		
		return jdbcTemplate.query(sql,
				(rs,rowNum)->
					new UserResponseDTO(rs.getString("user_id"),
							rs.getString("user_name"),
							rs.getString("user_password"),
							rs.getString("user_confirmpassword"),
							rs.getString("user_role")),
					"%"+Name+"%");
	}
	
public List<UserResponseDTO> selectUserByIdOrName(String Id, String Name) {
		
		String sql="select * from users where user_id=? OR user_name=?";
		
		return jdbcTemplate.query(sql,
				(rs,rowNum)->
					new UserResponseDTO(rs.getString("user_id"),
							rs.getString("user_name"),
							rs.getString("user_password"),
							rs.getString("user_confirmpassword"),
							rs.getString("user_role")),
					Id,Name);
	}
	
	public List<UserResponseDTO> selectAll(){
		
		String sql="select * from users";
		return jdbcTemplate.query(sql,
				(rs,rowNum)->
					new UserResponseDTO(rs.getString("user_id"),
							rs.getString("user_name"),
							rs.getString("user_password"),
							rs.getString("user_confirmpassword"),
							rs.getString("user_role"))
					);
	}
}
