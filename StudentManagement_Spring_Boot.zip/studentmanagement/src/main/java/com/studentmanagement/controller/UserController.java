package com.studentmanagement.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.studentmanagement.dao.UserDAO;
import com.studentmanagement.dto.UserRequestDTO;
import com.studentmanagement.dto.UserResponseDTO;
import com.studentmanagement.model.UserBean;



@Controller
public class UserController {
	@Autowired
	private UserDAO userdao;
	
	@ModelAttribute("UserBean")
	public UserBean getUserBean() {
		return new UserBean();
	}
	
	
	@GetMapping (value="/")
	public String Login(ModelMap model) {
		return "LGN001";
	}
	
	
	@GetMapping (value="/user")
	public String displayView(ModelMap model) {
		ArrayList<UserResponseDTO> userlist=(ArrayList<UserResponseDTO>) userdao.selectAll();
		model.addAttribute("userlist",userlist);
		return "USR003";
	}
	
	
	
	@RequestMapping(value="/searchuser", method=RequestMethod.POST)
	public String usersearch(@RequestParam("userID") String userID,@RequestParam("userName") String userName,
			ModelMap model) {
		List<UserResponseDTO> searchlist = new ArrayList<>();
		 if(userID.isEmpty()&& userName.isEmpty()) {
			searchlist= userdao.selectAll();
		}
		 else if(userID.isBlank()) {
			searchlist=userdao.selectUserByName(userName);
		}
		else if(userName.isBlank()) {
			searchlist=userdao.selectUserById(userID);
		} else {
			searchlist = userdao.selectUserByIdOrName(userID, userName);
		}
		
		
		model.addAttribute("userlist", searchlist);
		return "USR003";
	}
	
	
	
	@RequestMapping(value="/setupadduser", method=RequestMethod.GET)
	public ModelAndView adduser() {
		return new ModelAndView ("USR001", "UserBean", new UserBean());
	}
	
	@RequestMapping(value="/adduser", method=RequestMethod.POST)
	public String addUser(@ModelAttribute("UserBean") @Validated UserBean userBean, BindingResult bs,
			ModelMap model) {
		if(bs.hasErrors()) {
			return "USR001";
		}
		if(userBean.getUserID().equals("") || userBean.getUserName().equals("") || userBean.getUserPassword().equals("") || 
				userBean.getUserConfirmPassword().equals("")||userBean.getUserRole().equals("")) {
			model.addAttribute("error", "Fill Blanks!");			
			return "USR001";
			}else {
				UserRequestDTO  dto=new UserRequestDTO();
				dto.setUserID(userBean.getUserID());
				dto.setUserName(userBean.getUserName());
				dto.setUserPassword(userBean.getUserPassword());
				dto.setUserConfirmPassword(userBean.getUserConfirmPassword());
				dto.setUserRole(userBean.getUserRole());
				
				if(!dto.getUserPassword().equals(dto.getUserConfirmPassword())) {
					model.addAttribute("error","Password do not match!");
					return "USR001";
				}else {
					int rs=userdao.insertUser(dto);				
						if(rs==0) {
							model.addAttribute("error","Insert Failed");	
							return "USR001";
					}
						model.addAttribute("success", "Successful Register");
					
				}
				return "USR001";
			}
			
	}
	
	@RequestMapping(value="/setupUpdateUser", method=RequestMethod.GET)
	public  ModelAndView updateUser(@RequestParam ("userId") String userID) {
		UserRequestDTO dto=new UserRequestDTO();
		dto.setUserID(userID);
		return new ModelAndView ("USR002", "userBean", userdao.selectOne(dto));
	}
	
	@RequestMapping(value="/updateuser", method=RequestMethod.POST)
	public String updateUser(@ModelAttribute("userBean") @Validated UserBean userBean, BindingResult bs,
		ModelMap model) {
		
			if(bs.hasErrors()) {
				return "USR002";
			}
			
			if(userBean.getUserID().equals("") || userBean.getUserName().equals("") || userBean.getUserPassword().equals("") || 
					userBean.getUserConfirmPassword().equals("")||userBean.getUserRole().equals("") && 
					userBean.getUserPassword()!=userBean.getUserConfirmPassword()) {
				model.addAttribute("error", "Fill Blanks!");
				return "USR002";
				}else {
					UserRequestDTO  dto=new UserRequestDTO();
					dto.setUserID(userBean.getUserID());
					dto.setUserName(userBean.getUserName());
					dto.setUserPassword(userBean.getUserPassword());
					dto.setUserConfirmPassword(userBean.getUserConfirmPassword());
					dto.setUserRole(userBean.getUserRole());
					if(!dto.getUserPassword().equals(dto.getUserConfirmPassword())) {
						model.addAttribute("error","Password do not match!");
						return "USR002";
					}else {
						int rs=userdao.updateUser(dto);				
							if(rs==0) {
								model.addAttribute("error","Insert Failed");	
								return "USR002";
						}
							model.addAttribute("success", "Successful Updated");
						
					}
					return "USR002";	
				}	
		}
	
	@RequestMapping(value="/deleteUser", method=RequestMethod.GET)
	public String deleteuser(@RequestParam ("userId") String userID,ModelMap model) {
		UserRequestDTO dto=new UserRequestDTO();
		dto.setUserID(userID);
		int res=userdao.deleteUser(dto);
		if(res==0) {
			model.addAttribute("error", "Delete Failed");
		}
		return "USR003";
	}

}
