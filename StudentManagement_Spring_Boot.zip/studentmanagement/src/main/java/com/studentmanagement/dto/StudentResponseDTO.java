package com.studentmanagement.dto;

import java.util.List;

public class StudentResponseDTO {
	private String studentId;
	private String studentName;
	private String dob;
	private String gender;
	private String phone;
	private String education;
	private List<String> course;
	
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public List<String> getCourse() {
		return course;
	}
	public void setCourse(List<String> courseList) {
		this.course = courseList;
	}
	
	@Override
	public String toString() {
		return "StudentResponseDTO [studentId=" + studentId + ", studentName=" + studentName + ", dob=" + dob
				+ ", gender=" + gender + ", phone=" + phone + ", education=" + education + ", course=" + course + "]";
	}
	public StudentResponseDTO(String studentId, String studentName, String dob, String gender, String phone,
			String education) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.dob = dob;
		this.gender = gender;
		this.phone = phone;
		this.education = education;
	}
	public StudentResponseDTO(String studentId, String studentName) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
	}
	
	
	
}

