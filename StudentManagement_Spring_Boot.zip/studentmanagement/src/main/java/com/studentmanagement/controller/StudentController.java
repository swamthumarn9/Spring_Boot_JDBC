package com.studentmanagement.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.studentmanagement.dao.CourseDAO;
import com.studentmanagement.dao.StudentDAO;
import com.studentmanagement.dto.CourseResponseDTO;
import com.studentmanagement.dto.StudentRequestDTO;
import com.studentmanagement.dto.StudentResponseDTO;
import com.studentmanagement.dto.UserResponseDTO;
import com.studentmanagement.model.StudentBean;



@Controller
public class StudentController {
	@Autowired
	private StudentDAO studentdao;
	@Autowired
	private CourseDAO coursedao;
	
	@GetMapping (value="/students")
	public String displayView(ModelMap model) {			 	
	 	List<StudentResponseDTO> studentlist = studentdao.selectAll();
	 	for (StudentResponseDTO student : studentlist) {
			List<String> courselist = coursedao.selectCoursebyStudentId(student.getStudentId());
			student.setCourse(courselist);
		}
		model.addAttribute("studentlist",studentlist);
		return "STU003";
	} 
	
	@RequestMapping(value="/searchstudent", method=RequestMethod.POST)
	public String studentsearch(@RequestParam("studentId") String studentId,@RequestParam("studentName") String studentName, 
			@RequestParam("course") String course, ModelMap model) {
			String stuId= studentId.isBlank()?"@#$%": studentId;
			String stuName=studentName.isBlank()?"@#$%" :studentName;
			String stuCourse=course.isBlank()?"@#$%" : course;
			List<StudentResponseDTO> studentlist = new ArrayList<StudentResponseDTO>();
			
			/*
			if(studentId.isBlank() && studentName.isBlank() && course.isBlank()) {
				studentlist=studentdao.selectAll();				
				for (StudentResponseDTO student : studentlist) {
					List<String> courselist = coursedao.selectCoursebyStudentId(student.getStudentId());
					student.setCourse(courselist);
				}
				model.addAttribute("studentlist", studentlist);
				return "STU003";
			}
			else{ */
				studentlist=studentdao.selectStudentListByIdOrNameOrCourse(stuId, stuName, stuCourse);
				for (StudentResponseDTO student : studentlist) {
					List<String> courseList = coursedao.selectCoursebyStudentId(student.getStudentId());
					student.setCourse(courseList);
				}
				
				if(studentlist.size()==0) {
					studentlist=studentdao.selectAll();
					for (StudentResponseDTO student : studentlist) {
						List<String> courseList = coursedao.selectCoursebyStudentId(student.getStudentId());
						student.setCourse(courseList);
					}
					model.addAttribute("studentlist", studentlist);				
					return"STU003";
				}else {
					model.addAttribute("studentlist", studentlist);				
					return"STU003";
				}
				
				
				
			}
	
	

	@RequestMapping(value="/setupaddstudent", method=RequestMethod.GET)
	public ModelAndView addstudent(ModelMap model) {
		model.addAttribute("courselist",coursedao.selectAll());
		return new ModelAndView ("STU001", "studentBean", new StudentBean());
		
	}
	
	
	@RequestMapping(value="/addstudent", method=RequestMethod.POST)
	public String addstudent(@ModelAttribute("studentBean") @Validated StudentBean StudentBean, BindingResult bs,
			ModelMap model) {
		if(bs.hasErrors()) {
			List<CourseResponseDTO> courselist=coursedao.selectAll();
			model.addAttribute("courselist", courselist);
			return "STU001";
		}
		
		
		if(StudentBean.getStudentId().equals("") || StudentBean.getStudentName().equals("") || StudentBean.getDob().equals("") || 
				StudentBean.getGender().equals("")||StudentBean.getPhone().equals("") || StudentBean.getEducation().equals("")) {
			
			model.addAttribute("error", "Fill Blanks!");
			return "STU001";
			}else {
				StudentRequestDTO  dto=new StudentRequestDTO();
				dto.setStudentId(StudentBean.getStudentId());
				dto.setStudentName(StudentBean.getStudentName());
				dto.setDob(StudentBean.getDob());
				dto.setGender(StudentBean.getGender());
				dto.setPhone(StudentBean.getPhone());
				dto.setEducation(StudentBean.getEducation());			
				int rs=studentdao.insertStudent(dto);
				List<String> courseattend=StudentBean.getCourse();
				for (String course:courseattend) {
						studentdao.addCourseForStrudent(StudentBean.getStudentId(),course);
					}
				
				if(rs==0) {
					model.addAttribute("error","Insert Failed");
					return "STU001";
				}
				model.addAttribute("success", "Successful Register");
				return "STU001";
			}
	}
	
	@RequestMapping(value="/setupUpdateStudent", method=RequestMethod.GET)
	public  ModelAndView updateUser(@RequestParam ("studentId") String studentId, ModelMap model, HttpSession session) {		
		StudentRequestDTO dto = new StudentRequestDTO();
		dto.setStudentId(studentId);
		StudentResponseDTO student = studentdao.selectStudentById(studentId);
		List<CourseResponseDTO> courselist=coursedao.selectAll();
		List<CourseResponseDTO> courseattend = coursedao.selectCoursesByStudentId(studentId);
		
		ArrayList<String> stucourse=new ArrayList<String>();
			for(CourseResponseDTO course:courseattend) {
				stucourse.add(course.getCourseId());
			}
			
		StudentBean sbean=new StudentBean();
			sbean.setStudentId(student.getStudentId());
			sbean.setStudentName(student.getStudentName());
			sbean.setDob(student.getDob());
			sbean.setGender(student.getGender());
			sbean.setPhone(student.getPhone());
			sbean.setEducation(student.getEducation());
			sbean.setCourse(stucourse);
			model.addAttribute("courselist",courselist);
		return new ModelAndView ("STU002", "studentBean", sbean);
	}
	
	
	
	@RequestMapping(value="/updatestudent", method=RequestMethod.POST)
	public String updateUser(@ModelAttribute("studentBean") @Validated StudentBean StudentBean, BindingResult bs,
		ModelMap model) {
		
			if(bs.hasErrors()) {
				return "USR002";
			}
			
			if(StudentBean.getStudentId().equals("") || StudentBean.getStudentName().equals("") || StudentBean.getDob().equals("") || 
					StudentBean.getGender().equals("")||StudentBean.getPhone().equals("") || StudentBean.getEducation().equals("")) {
				
				model.addAttribute("error", "Fill Blanks!");
				return "STU002";
				}else {
					StudentRequestDTO  dto=new StudentRequestDTO();
					dto.setStudentId(StudentBean.getStudentId());
					dto.setStudentName(StudentBean.getStudentName());
					dto.setDob(StudentBean.getDob());
					dto.setGender(StudentBean.getGender());
					dto.setPhone(StudentBean.getPhone());
					dto.setEducation(StudentBean.getEducation());
					int rs=studentdao.updateStudent(dto);
					
					coursedao.selectCoursebyStudentId(dto.getStudentId());
					//To Fix
					studentdao.deleteStudentCourseByStudentId(dto.getStudentId());
					List<String> courseattend=StudentBean.getCourse();
					for (String course:courseattend) {
							studentdao.addCourseForStrudent(StudentBean.getStudentId(),course);
						}					
					
					
					if(rs==0) {
						model.addAttribute("error","Insert Failed");
						return "STU002";
					}
					model.addAttribute("success", "Successful Register");
					return "STU002";
				}
		}
	
	@RequestMapping(value="/deleteStudent", method=RequestMethod.GET)
	public String deletestudent(@RequestParam ("studentId") String studentId,ModelMap model) {
		StudentRequestDTO dto=new StudentRequestDTO();
		dto.setStudentId(studentId);
	//	studentdao.deleteStudentCoursebyStudentId(studentId);
		int res=studentdao.deleteStudent(dto);
		studentdao.deleteStudentCourseByStudentId(dto.getStudentId());
		if(res==0) {
			model.addAttribute("error", "Delete Failed");
		}
		return "STU003";
	}
	
}
